import React, { useEffect } from 'react';
import Layout from '@/components/layout/Layout';
import Hero from '@/components/home/Hero';
import Services from '@/components/home/Services';
import Stats from '@/components/home/Stats';
import Testimonials from '@/components/home/Testimonials';
import CallToAction from '@/components/home/CallToAction';

const Index = () => {
  // Scroll animation function
  useEffect(() => {
    const reveal = () => {
      const reveals = document.querySelectorAll('.reveal');
      
      for (let i = 0; i < reveals.length; i++) {
        const windowHeight = window.innerHeight;
        const elementTop = reveals[i].getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < windowHeight - elementVisible) {
          reveals[i].classList.add('active');
        } else {
          reveals[i].classList.remove('active');
        }
      }
    };

    window.addEventListener('scroll', reveal);
    // Trigger once to reveal elements that are already visible
    reveal();
    
    return () => {
      window.removeEventListener('scroll', reveal);
    };
  }, []);

  return (
    <Layout>
      <Hero />
      <div className="reveal fade-bottom">
        <Services />
      </div>
      <div className="reveal fade-bottom">
        <Stats />
      </div>
      <div className="reveal fade-bottom">
        <Testimonials />
      </div>
      <div className="reveal fade-bottom">
        <CallToAction />
      </div>
    </Layout>
  );
};

export default Index;
