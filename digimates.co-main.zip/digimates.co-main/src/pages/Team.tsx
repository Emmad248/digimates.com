import React from 'react';
import Layout from '@/components/layout/Layout';
import SectionTitle from '@/components/common/SectionTitle';
import TeamMember from '@/components/common/TeamMember';

const Team = () => {
  const teamMembers = [
    {
      name: 'Emmad Arshad',
      role: 'CEO & Founder (Search Engine Optimizer)',
      image: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b',
      socialLinks: {
        linkedin: 'https://www.linkedin.com/in/emmad-seo-specialist-founder-and-ceo-at-digimates/',
        whatsapp: 'https://wa.me/923109849018',
        email: 'emmadarshad1@gmail.com'
      }
    },
    {
      name: 'Zohaib Islam',
      role: 'CEO & Co-Founder (App Developer)',
      image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6',
      socialLinks: {
        linkedin: 'https://www.linkedin.com/in/zohaib-islam-3999b3227/',
        whatsapp: 'https://wa.me/923090486206'
      }
    },
    {
      name: 'Zaheer Shah',
      role: 'CEO & Co-Founder (Web Developer)',
      image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d',
      socialLinks: {
        linkedin: 'https://www.linkedin.com/in/syed-zaheer-hussain-shah/',
        whatsapp: 'https://wa.me/923420726826'
      }
    },
    {
      name: 'Aliza Ayaz',
      role: 'SEO Expert',
      image: 'https://images.unsplash.com/photo-1488590528505-98d2b5aba04b',
      socialLinks: {}
    },
    {
      name: 'Maryam Choudhary',
      role: 'Graphic Designer',
      image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d',
      socialLinks: {}
    },
    {
      name: 'Ahmed Sheikh',
      role: 'Junior Web Developer',
      image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085',
      socialLinks: {}
    }
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-r from-digimate-800 to-digimate-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Meet Our Team</h1>
            <p className="text-xl">Founded in 2024</p>
          </div>
        </div>
      </section>

      {/* Team Overview */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <SectionTitle 
            title="Our Experts" 
            subtitle="Our team of dedicated professionals combines creativity, technical expertise, and strategic thinking to deliver exceptional results."
          />
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <TeamMember 
                key={index}
                name={member.name}
                role={member.role}
                image={member.image}
                socialLinks={member.socialLinks}
              />
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Team;
