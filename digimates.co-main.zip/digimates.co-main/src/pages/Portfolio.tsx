
import React, { useState } from 'react';
import Layout from '@/components/layout/Layout';
import SectionTitle from '@/components/common/SectionTitle';
import ProjectCard from '@/components/common/ProjectCard';

const Portfolio = () => {
  // Category filter options
  const categories = ['All', 'Web Development', 'App Development', 'UI/UX Design', 'Branding', 'Digital Marketing'];
  
  const [activeCategory, setActiveCategory] = useState('All');
  
  const projects = [
    {
      image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d',
      title: 'E-commerce Website',
      category: 'Web Development',
      link: '#'
    },
    {
      image: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158',
      title: 'Finance Mobile App',
      category: 'App Development',
      link: '#'
    },
    {
      image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085',
      title: 'Content Management System',
      category: 'Web Development',
      link: '#'
    },
    {
      image: 'https://images.unsplash.com/photo-1487887235947-a955ef187fcc',
      title: 'Travel App UI Design',
      category: 'UI/UX Design',
      link: '#'
    },
    {
      image: 'https://images.unsplash.com/photo-1487958449943-2429e8be8625',
      title: 'Brand Identity Design',
      category: 'Branding',
      link: '#'
    },
    {
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f',
      title: 'Marketing Campaign',
      category: 'Digital Marketing',
      link: '#'
    },
    {
      image: 'https://images.unsplash.com/photo-1481487196290-c152efe083f5',
      title: 'Corporate Website',
      category: 'Web Development',
      link: '#'
    },
    {
      image: 'https://images.unsplash.com/photo-1483058712412-4245e9b90334',
      title: 'Healthcare Platform',
      category: 'Web Development',
      link: '#'
    },
    {
      image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173',
      title: 'Food Delivery App',
      category: 'App Development',
      link: '#'
    },
    {
      image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853',
      title: 'Social Media Management',
      category: 'Digital Marketing',
      link: '#'
    },
    {
      image: 'https://images.unsplash.com/photo-1492551557933-34265f7af79e',
      title: 'UI Component Library',
      category: 'UI/UX Design',
      link: '#'
    },
    {
      image: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935',
      title: 'Corporate Identity',
      category: 'Branding',
      link: '#'
    }
  ];

  // Filter projects based on active category
  const filteredProjects = activeCategory === 'All' 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  return (
    <Layout>
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-r from-digimate-800 to-digimate-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Portfolio</h1>
            <p className="text-xl">
              Explore our collection of work that showcases our expertise, creativity, and commitment to excellence.
            </p>
          </div>
        </div>
      </section>

      {/* Portfolio Gallery */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <SectionTitle 
            title="Our Projects" 
            subtitle="Browse through our latest work and see how we've helped our clients achieve their digital goals."
          />
          
          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category, index) => (
              <button
                key={index}
                className={`px-4 py-2 rounded-md transition-colors ${
                  activeCategory === category 
                    ? 'bg-digimate-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          
          {/* Projects Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project, index) => (
              <ProjectCard 
                key={index}
                image={project.image}
                title={project.title}
                category={project.category}
                link={project.link}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Have a Project in Mind?</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Let's discuss how we can help bring your vision to life with our expertise and creativity.
          </p>
          <a 
            href="/contact" 
            className="inline-block px-8 py-3 bg-digimate-600 text-white rounded-md hover:bg-digimate-700 transition-colors"
          >
            Contact Us
          </a>
        </div>
      </section>
    </Layout>
  );
};

export default Portfolio;
