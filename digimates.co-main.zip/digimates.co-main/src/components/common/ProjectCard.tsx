
import React, { useState } from 'react';

interface ProjectCardProps {
  image: string;
  title: string;
  category: string;
  link?: string;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ image, title, category, link }) => {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className="relative overflow-hidden rounded-lg group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <img 
        src={image} 
        alt={title} 
        className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110" 
      />
      <div 
        className={`absolute inset-0 bg-digimate-800 bg-opacity-80 flex flex-col items-center justify-center p-4 transition-opacity duration-300 ${
          isHovered ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <h3 className="text-white text-xl font-semibold mb-2 text-center">{title}</h3>
        <p className="text-digimate-300 mb-4">{category}</p>
        {link && (
          <a 
            href={link} 
            className="inline-block px-4 py-2 bg-white text-digimate-800 rounded-md hover:bg-digimate-100 transition-colors"
            target="_blank" 
            rel="noopener noreferrer"
          >
            View Project
          </a>
        )}
      </div>
    </div>
  );
};

export default ProjectCard;
