
import React from 'react';
import { Linkedin, Mail, MessageSquare } from 'lucide-react';

interface TeamMemberProps {
  name: string;
  role: string;
  image: string;
  socialLinks?: {
    linkedin?: string;
    whatsapp?: string;
    email?: string;
  };
}

const TeamMember: React.FC<TeamMemberProps> = ({ name, role, image, socialLinks }) => {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md group">
      <div className="relative overflow-hidden flex justify-center py-6">
        <img 
          src={image}
          alt={`${name} avatar`}
          className="w-24 h-24 rounded-full object-cover"
        />
      </div>
      <div className="p-4 text-center">
        <h3 className="text-lg font-semibold">{name}</h3>
        <p className="text-digimate-600">{role}</p>
        {(socialLinks?.linkedin || socialLinks?.whatsapp || socialLinks?.email) && (
          <div className="mt-4 flex justify-center gap-2">
            {socialLinks.linkedin && (
              <a 
                href={socialLinks.linkedin}
                className="bg-gray-100 p-2 rounded-full hover:bg-digimate-100 transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Linkedin className="h-5 w-5 text-digimate-600" />
              </a>
            )}
            {socialLinks.whatsapp && (
              <a 
                href={socialLinks.whatsapp}
                className="bg-gray-100 p-2 rounded-full hover:bg-digimate-100 transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageSquare className="h-5 w-5 text-digimate-600" />
              </a>
            )}
            {socialLinks.email && (
              <a 
                href={`mailto:${socialLinks.email}`}
                className="bg-gray-100 p-2 rounded-full hover:bg-digimate-100 transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Mail className="h-5 w-5 text-digimate-600" />
              </a>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default TeamMember;
