
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";

const Stats = () => {
  const stats = [
    { number: '25+', label: 'Projects Completed' },
    { number: '15+', label: 'Happy Clients' },
    { number: '5+', label: 'Years of Experience' },
    { number: '10+', label: 'Team Members' }
  ];

  return (
    <section className="py-20 bg-gradient-to-r from-digimate-800 to-digimate-900">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-white/10 border-none text-white">
              <CardContent className="p-6 text-center">
                <h3 className="text-4xl font-bold mb-2">{stat.number}</h3>
                <p className="text-lg">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;
