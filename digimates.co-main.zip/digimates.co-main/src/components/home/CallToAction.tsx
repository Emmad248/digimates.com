
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const CallToAction = () => {
  return (
    <section className="py-20 bg-gradient-to-r from-digimate-800 to-digimate-900 text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Transform Your Digital Presence?</h2>
        <p className="text-xl mb-8 max-w-3xl mx-auto">
          Partner with DigiMates to create exceptional digital experiences that drive growth and deliver measurable results for your business.
        </p>
        <div className="flex flex-wrap gap-4 justify-center">
          <Button asChild className="bg-white text-digimate-800 hover:bg-gray-100">
            <Link to="/contact">Get Started</Link>
          </Button>
          <Button asChild variant="outline" className="border-white text-white hover:bg-white hover:text-digimate-800">
            <Link to="/portfolio">View Our Work</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;
