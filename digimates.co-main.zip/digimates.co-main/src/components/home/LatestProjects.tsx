
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import SectionTitle from '../common/SectionTitle';
import ProjectCard from '../common/ProjectCard';

const LatestProjects = () => {
  const projects = [
    {
      image: 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d',
      title: 'E-commerce Website',
      category: 'Web Development'
    },
    {
      image: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158',
      title: 'Finance Mobile App',
      category: 'App Development'
    },
    {
      image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085',
      title: 'Content Management System',
      category: 'Web Development'
    },
    {
      image: 'https://images.unsplash.com/photo-1487958449943-2429e8be8625',
      title: 'Brand Identity Design',
      category: 'Branding'
    }
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <SectionTitle 
          title="Latest Projects" 
          subtitle="Take a look at some of our recent work that showcases our expertise and creativity."
        />
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {projects.map((project, index) => (
            <ProjectCard 
              key={index}
              image={project.image}
              title={project.title}
              category={project.category}
            />
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button asChild className="bg-digimate-600 hover:bg-digimate-700">
            <Link to="/portfolio">View All Projects</Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default LatestProjects;
