
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const Hero = () => {
  return (
    <section className="relative bg-gradient-to-r from-digimate-950 to-digimate-800 text-white py-20 md:py-32">
      {/* Abstract shapes in background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-32 -left-10 w-72 h-72 bg-digimate-500 opacity-10 rounded-full"></div>
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-digimate-300 opacity-10 rounded-full"></div>
        <div className="absolute top-1/4 right-1/3 w-48 h-48 bg-digimate-600 opacity-10 rounded-full"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="animate-slide-right">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Creative Digital Solutions for Your Business
            </h1>
            <p className="text-lg md:text-xl text-gray-100 mb-8">
              We create stunning digital experiences that transform your brand and drive growth. Our expert team brings your vision to life with cutting-edge technology.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button asChild className="bg-digimate-600 hover:bg-digimate-700 text-white px-8 py-6">
                <Link to="/portfolio">See Our Work</Link>
              </Button>
              <Button asChild variant="outline" className="text-white border-white hover:bg-white hover:text-digimate-800 px-8 py-6">
                <Link to="/contact">Contact Us</Link>
              </Button>
            </div>
          </div>

          <div className="hidden md:block animate-slide-up">
            <img 
              src="https://images.unsplash.com/photo-1460925895917-afdab827c52f" 
              alt="Digital Solutions" 
              className="rounded-lg shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
