
import React from 'react';
import SectionTitle from '../common/SectionTitle';

const Testimonials = () => {
  const testimonials = [
    {
      quote: "DigiMates transformed our online presence with a beautiful website that perfectly captures our brand. Their team was professional, responsive, and delivered exceptional results.",
      author: "Sarah Johnson",
      position: "CEO, TechVision",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop"
    },
    {
      quote: "Working with DigiMates on our mobile app was a fantastic experience. They understood our vision and created an intuitive, user-friendly application that our customers love.",
      author: "Michael Chen",
      position: "Founder, InnovatePay",
      image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop"
    },
    {
      quote: "The digital marketing strategy DigiMates developed for us has generated outstanding results. Our online visibility has increased significantly, leading to more leads and sales.",
      author: "Emma Rodriguez",
      position: "Marketing Director, GrowthFocus",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop"
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <SectionTitle 
          title="What Our Clients Say" 
          subtitle="Don't just take our word for it. Here's what our clients have to say about working with DigiMates."
        />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-lg">
              <div className="mb-6">
                <svg className="h-8 w-8 text-digimate-400" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                </svg>
              </div>
              <p className="text-gray-600 mb-6">"{testimonial.quote}"</p>
              <div className="flex items-center">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.author} 
                  className="h-12 w-12 rounded-full object-cover mr-4" 
                />
                <div>
                  <p className="font-semibold">{testimonial.author}</p>
                  <p className="text-sm text-gray-500">{testimonial.position}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
